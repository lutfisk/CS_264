Open the .asm file with the appropriate program, build and run.
The user is prompted for a value of n (no larger than 46 and 0 terminates the program).
The sequence of numbers are also stored in an array and prints out in order. The
program does not accept more than 46th number because of the architecture of 32bit
registers, and thus was set at that limit in order to avoid overflow.