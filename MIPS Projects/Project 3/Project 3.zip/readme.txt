Open the .asm file with the appropriate program, build and run.
The user is prompted for a number of elements (n) in the stack.
The program then prompts n times for integers which the user will put in one by one.
The computer will then print out with new line for each number in descending order
(highest first to low), directly from the stack.